---
name: apadore-prispevky-linkedin
description: Vytvoří ve Figmě vizuál k příspěvku na LinkedIn (a další sociální sítě) podle brand manuálu Apadore 2026. Dvě šablony: Myšlenka (citát nebo teze, autor nahoře) a Fotka s citátem. Autor příspěvků je Mikoláš Voborský. Použij vždy, když někdo chce „příspěvek na LinkedIn“, „cover k příspěvku“, „citát na LinkedIn“, „vizuál k postu“, „story“, nebo vloží text příspěvku a chce k němu obrázek. Hlídá české uvozovky a všechna pravidla značky. Obálky článků na web řeší skill apadore-blog-cover.
---

# Příspěvky na LinkedIn: Apadore

Skill skládá vizuály výhradně ze schválených šablon v brand manuálu. Nic nekreslí od nuly, nevymýšlí nové styly a **nemění nic mimo stránku Brand manuál**.

## Kde co je

- **Figma soubor:** Apadore 2026 (NEW Web), file key `g6aje2QLWx5USCXogBP68K`, stránka `↪ Brand manuál` (id `2024:5678`).
- **Sociální kit · základní** (sekce `2043:5715`): běžně používané výstupy.
- **Sociální kit · rozšířený** (sekce `2110:8585`): všechny varianty ve formátech na výšku (1200 × 1504), čtverec (1200 × 1200) a reels (9 : 16).
- **Logo:** komponenta `Logo` (`2037:5682`), varianty Pozitivní (navy) a Negativní (bílá). Vždy jako instance.

### Typy příspěvků (rozšířený kit)

| Typ | Kdy | Zarovnání | Značka | Na výšku tmavá / světlá |
| --- | --- | --- | --- | --- |
| **A · Myšlenka** | delší teze na 2 až 3 řádky | vlevo | štítek „Mikoláš Voborský · Apadore“ bez fotky | `2127:8592` / `2127:8599` |
| **A2 · Myšlenka s fotkou** | speciální, osobní | vlevo | štítek s profilovkou | `2127:8607` / `2127:8615` |
| **B · Krátký citát** | 1 až 2 řádky | na střed | logo Apadore dole uprostřed | `2127:8624` / `2127:8633` |
| **C · Citát s autorem** | 1 až 2 řádky | na střed | štítek s profilovkou | `2131:8596` / `2131:8605` |
| **D · Příspěvek** | delší titulek, štítek „Nový článek“ | vlevo | logo vpravo dole | `2127:8643` / `2127:8652` |
| **E1 · Příspěvek s grafikou** | k článku z blogu | vlevo | podpis autora | `2146:8600` / `2146:8644` |
| **E2 · Příspěvek s grafikou** | k článku z blogu | na střed | logo dole uprostřed | `2146:8777` / `2146:8802` |
| **F · Case study** | nový projekt | vlevo dole | logo vpravo dole | `2146:8878` (Linstram) |
| **Fotka s citátem · Z praxe** | osobní příběh | skleněný rámeček nahoře | – | `2121:8807` |

Čtverce: A `2127:8663`, A2 `2127:8678`, B `2127:8695`, C `2131:8613`, D `2127:8714`, E1 `2146:8688`, E2 `2146:8827`, F `2146:8886`, Fotka `2121:8818`.
Reels (jen na střed a case study): B `2127:8774`, C `2131:8630`, F `2146:8894`, Fotka `2121:8829`. U reels nechte volné horní 14 % a spodní 20 % plochy (vrstvy „Bezpečná zóna“, skryté).

### Základní kit a profilový set

Myšlenka tmavá `2043:5737` a světlá `2043:5729`, Fotka s citátem `2043:5745`, Otázka 16 : 9 `2043:5755`, Hledáme posilu `2043:5763`, LinkedIn banner tmavý `2147:3712` a světlý `2060:5778`, profilová fotka tmavá `2060:5783` a světlá `2060:5787`, Clutch `2063:5791`.

### Jak vybrat typ

- Krátký citát (do 2 řádků): **B** nebo **C**. Delší teze: **A** (A2, když má být vidět autor).
- Sdílení článku: **E1/E2** s grafickým prvkem z obálky blogu (`↪ Blog [Covers]`), nebo **D** bez grafiky.
- Projekt: **F** s fotkou z case study.
- Tmavá verze je výchozí, světlá doplňková (menšina příspěvků).

## Postup

1. **Zjisti zadání:** text příspěvku nebo hlavní myšlenku, šablonu (Myšlenka / Fotka s citátem), formát (výchozí na výšku 1080 × 1350), tmavou nebo světlou verzi (výchozí tmavá). U fotky s citátem si vyžádej fotku.
2. **Navrhni citát:** z textu příspěvku vyber nebo zkrať jednu větu, max. 3 řádky (orientačně do 60 znaků). Nabídni 2 až 3 varianty, pokud citát nebyl zadán.
3. **Uprav text podle pravidel** níže, hlavně uvozovky.
4. **Načti skill `figma-use`** a pracuj přes `use_figma`.
5. **Naklonuj šablonu** (`node.clone()`) do sekce `Příspěvky / <RRRR-MM>` na stránce Brand manuál (založ ji, pokud chybí). Pojmenuj `<RRRR-MM-DD> · <téma> · <Myšlenka|Fotka s citátem> · <Tmavá|Světlá>`.
6. **Vyměň obsah.** Před změnou textu načti fonty přes `getStyledTextSegments(['fontName'])`. Fotky nahrávej přes `upload_assets` s `nodeIds`. Autor je vždy **Mikoláš Voborský**, pokud uživatel neřekne jinak.
7. **Zkontroluj screenshotem:** text se nepřekrývá a nepřetéká, citát má max. 3 řádky (jinak zkrať text, písmo nezmenšuj), logo a autor jsou na místě.
8. **Předej:** název rámce. Export PNG ve 2× jen na požádání.

## Pravidla značky

- **Barvy:** navy 900 `#090E21`, bílá a šedé z palety. Tmavá verze je primární a tvoří většinu příspěvků, světlý přechod je doplňkový.
- **Červená tečka** (`#FF5A1F`) jen uvnitř skleněného prvku: grafika z obálek blogu (E1, E2) a štítek „Z praxe“. Jinak žádná červená.
- **Písma:** Booton SemiBold pro citáty a nadpisy, Geist pro autora a odkaz. **Žádná kurzíva**, žádné barevné zvýraznění slov. Zvýrazňuje se jen velikostí a řezem.
- **Logo:** jen instance komponenty Logo, negativní na tmavém, pozitivní na světlém.
- **Jedna myšlenka na vizuál.** Vysvětlení patří do textu příspěvku.

## Pravidla textu

- **České uvozovky vždy:** „takto“, tedy dolní `„` (U+201E) na začátku a horní `“` (U+201C) na konci. Nikdy "rovné", “anglické” ani ”obrácené”. Vnořené ‚takto‘. Je-li citát celá věta, tečka je před koncovou uvozovkou: „Nevybrali nás.“
- Vykání, „Apadore“ (verzálky jen v logu), žádná dlouhá pomlčka (—), čísla s mezerou po tisících (1 641).
- Jednopísmenné předložky a spojky (k, s, v, z, o, u, a, i) nenechávej na konci řádku, použij pevnou mezeru (U+00A0).
- Tón: klidně, věcně, přínos pro klienta, důkazy místo superlativů.

## Kontrola před předáním

- [ ] Správná šablona, výchozí tmavá verze na výšku
- [ ] České uvozovky „…“, žádná kurzíva, žádná dlouhá pomlčka
- [ ] Červená jen jako tečka ve skle
- [ ] Autor Mikoláš Voborský (pokud nebylo řečeno jinak)
- [ ] Logo je instance komponenty Logo
- [ ] Citát max. 3 řádky, nic nepřetéká (screenshot)
- [ ] Nic mimo stránku Brand manuál nebylo změněno
