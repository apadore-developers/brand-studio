---
name: apadore-prispevky-linkedin
description: Vytvoří ve Figmě vizuál k příspěvku na LinkedIn podle brand manuálu Apadore 2026 (formát 1080 × 1350, eyebrow vlevo nahoře, logo vpravo dole). Šablony Myšlenka, Nový článek s grafikou, Nový článek text a Case study, vždy tmavá (výchozí) nebo světlá. Použij vždy, když někdo chce „příspěvek na LinkedIn“, „vizuál k postu“, „post k článku“, „case study na LinkedIn“, nebo vloží text příspěvku a chce k němu obrázek. Hlídá české uvozovky a pravidla značky. Obálky článků na web řeší skill apadore-blog-cover, profilovky a covery Social media Basic Kit.
---

# Příspěvky na LinkedIn: Apadore

Skill skládá vizuály výhradně ze schválených šablon na stránce **SM Styl postů**. Nic nekreslí od nuly, nevymýšlí nové styly a nemění šablony samotné.

## Kde co je

- **Figma soubor:** Apadore 2026 (NEW Web) – Copy, file key `39VjOmXGf9jAkh1yXBg8SJ`.
  - **SM Styl postů** (stránka `4001:220915`, rámec `Social kit styl postů pracovní` `4001:220916`): šablony příspěvků.
  - **Social media Basic Kit** (`4001:79156`): profilovky, covery, loga. Příspěvky tam nepatří.
  - **BRAND MANUAL** (`2024:5678`): pravidla značky.
- Starý soubor `g6aje2QLWx5USCXogBP68K` se už nepoužívá.
- **Logo:** komponenta Logo, varianta Pozitivní `2037:5678` (navy, na světlém) a Negativní `2037:5680` (bílá, ztenčená, na tmavém). Vždy jen instance, nikdy odpojená nebo překreslená.
- **Online manuál:** https://brand-studio-eight-theta.vercel.app (kapitola Sociální sítě).

## Šablony (všechny 1080 × 1350)

| Typ | Kdy | Tmavá (výchozí) | Světlá |
| --- | --- | --- | --- |
| **Myšlenka** | teze nebo otázka na 2 až 3 řádky, eyebrow např. „Přečtěte si v příspěvku“ | `4001:220919` | `4001:220925` |
| **Nový článek · s grafikou** | sdílení článku z blogu, titulek nahoře a skleněný prvek z obálky blogu uprostřed | `4001:220952` | `4001:220973` |
| **Nový článek · text** | sdílení článku bez grafiky, delší titulek uprostřed | `4001:221019` | `4001:221024` |
| **Case study** | nový projekt, fotka nebo mockup přes celou plochu, název klienta a podtitulek vlevo dole | `4001:220994` (Linstram) | – |

Fotka s citátem (`4001:221029`, `4001:221037`, `4001:221046`) je zatím ve stádiu návrhu: nepoužívej ji, pokud o ni uživatel výslovně nepožádá.

### Společné rozvržení

- **Eyebrow** vlevo nahoře (x 86, y 86): IBM Plex Mono Medium 21,6 px, verzálky, krátce („Nový článek“, „Case study“, „Přečtěte si v příspěvku“).
- **Headline:** Booton SemiBold, vlevo od x 86, šířka max. 907 px.
  - velký (Myšlenka, Nový článek · text): ~100 px, proklad **105 %**;
  - menší (Nový článek · s grafikou, 40 až 96 px): proklad **110 %**.
- **Podtitulek / autor:** Geist Medium 30 px.
- **Logo** vpravo dole (x 808, y 1257, šířka 198): negativní na tmavém, pozitivní na světlém.
- Okraj 86 px ze všech stran, nic do něj nezasahuje.

### Jak vybrat typ

- Krátká myšlenka nebo otázka: **Myšlenka**.
- Článek z blogu: **Nový článek · s grafikou** (když existuje obálka blogu se skleněným prvkem), jinak **Nový článek · text**.
- Projekt: **Case study** s fotkou nebo mockupem z case study.
- Tmavá verze je výchozí, světlá doplňková (menšina příspěvků).

## Postup

1. **Zjisti zadání:** text příspěvku nebo hlavní myšlenku, typ šablony, tmavou nebo světlou verzi (výchozí tmavá). U case study si vyžádej fotku nebo screenshot webu.
2. **Navrhni headline:** jedna věta, max. 3 řádky (orientačně do 60 znaků). Když nebyl zadán, nabídni 2 až 3 varianty.
3. **Uprav text podle pravidel** níže, hlavně uvozovky a pevné mezery.
4. **Načti skill `figma-use`** a pracuj přes `use_figma`.
5. **Naklonuj šablonu** (`node.clone()`) na stránku SM Styl postů do sekce `Příspěvky / <RRRR-MM>` vedle pracovního rámce (založ ji, pokud chybí). Šablony v pracovním rámci neměň. Pojmenuj `<RRRR-MM-DD> · <téma> · <typ> · <Tmavá|Světlá>`.
6. **Vyměň obsah.** Před změnou textu načti fonty přes `getStyledTextSegments(['fontName'])`. Fotky nahrávej přes `upload_assets` s `nodeIds`. Proklad nech podle šablony (105 % / 110 %).
7. **Zkontroluj screenshotem:** nic nepřetéká ani se nepřekrývá s logem, headline má max. 3 řádky (jinak zkrať text, písmo nezmenšuj), logo je instance správné varianty.
8. **Předej:** odkaz na rámec ve Figmě. Export PNG 1080 × 1350 (1×) nebo 2× na požádání.

## Pravidla značky

- **Barvy:** tmavý přechod z navy 900 `#090E21` je výchozí, světlý přechod doplňkový. Žádné jiné pozadí.
- **Červená tečka** (`#FF5A1F`) jen uvnitř skleněného prvku z obálek blogu. Jinak žádná červená.
- **Písma:** Booton SemiBold (headline), Geist (podtitulek, autor), IBM Plex Mono (eyebrow). **Žádná kurzíva**, žádné barevné zvýraznění slov. Zvýrazňuje se jen velikostí a řezem.
- **Logo:** jen instance komponenty Logo, negativní na tmavém, pozitivní na světlém, vždy vpravo dole.
- **Jedna myšlenka na vizuál.** Vysvětlení patří do textu příspěvku.

## Pravidla textu

- **České uvozovky vždy:** „takto“, tedy dolní `„` (U+201E) na začátku a horní `“` (U+201C) na konci. Nikdy "rovné" ani “anglické”. Vnořené ‚takto‘.
- Vykání, „Apadore“ (verzálky jen v logu), žádná dlouhá pomlčka (—), čísla s mezerou po tisících (1 641).
- Jednopísmenné předložky a spojky (k, s, v, z, o, u, a, i) nenechávej na konci řádku, použij pevnou mezeru (U+00A0).
- Tón: klidně, věcně, přínos pro klienta, důkazy místo superlativů.

## Kontrola před předáním

- [ ] Formát 1080 × 1350, správná šablona, výchozí tmavá
- [ ] Eyebrow vlevo nahoře, logo vpravo dole (instance, správná varianta)
- [ ] Proklad 105 % u velkého headline, 110 % u menšího
- [ ] České uvozovky „…“, žádná kurzíva, žádná dlouhá pomlčka
- [ ] Červená jen jako tečka ve skle
- [ ] Headline max. 3 řádky, nic nepřetéká (screenshot)
- [ ] Šablony v pracovním rámci zůstaly beze změny
