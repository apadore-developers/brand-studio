---
name: apadore-prispevky-linkedin
description: Vytvoří ve Figmě vizuál k příspěvku na LinkedIn (a další sociální sítě) podle brand manuálu Apadore 2026. Dvě šablony: Myšlenka (citát nebo teze, autor nahoře) a Fotka s citátem. Autor příspěvků je Mikoláš Voborský. Použij vždy, když někdo chce „příspěvek na LinkedIn“, „cover k příspěvku“, „citát na LinkedIn“, „vizuál k postu“, „story“, nebo vloží text příspěvku a chce k němu obrázek. Hlídá české uvozovky a všechna pravidla značky. Obálky článků na web řeší skill apadore-blog-cover.
---

# Příspěvky na LinkedIn: Apadore

Skill skládá vizuály výhradně ze schválených šablon v brand manuálu. Nic nekreslí od nuly, nevymýšlí nové styly a **nemění nic mimo stránku Brand manuál**.

## Kde co je

- **Figma soubor:** Apadore 2026 (NEW Web), file key `g6aje2QLWx5USCXogBP68K`
- **Stránka:** `↪ Brand manuál` (id `2024:5678`), sekce **Šablony pro sociální sítě** (`2030:5678`)
- **Logo:** komponenta `Logo` (`2037:5682`), varianty `Barva=Pozitivní` (navy) a `Barva=Negativní` (bílá). Vždy jako instance.

### Šablona 1: Myšlenka (citát nebo teze)

Tmavé (primární) nebo světlé (doplňkové) pozadí s přechodem. Nahoře vlevo fotka a jméno autora, nahoře vpravo „Přečtěte si v příspěvku ↗“, uprostřed citát velkým písmem Booton, dole malé logo.

| Formát | Tmavá (primární) | Světlá (doplňková) |
| --- | --- | --- |
| Na výšku 1080 × 1350 (výchozí) | `2063:5719` | `2063:5729` |
| Čtverec 1200 × 1200 | `2063:5739` | `2063:5749` |
| Story 1080 × 1920 | `2063:5759` | `2063:5769` |

Vrstvy k úpravě: `Nadpis` (citát), `Autor`, `Odkaz`, `Avatar (fotka Mikoláše Voborského)`.

### Šablona 2: Fotka s citátem

Vlastní nearanžovaná fotka přes celou plochu (selfie, kancelář, tým), nahoře bílý rámeček s citátem, vpravo dole negativní logo.

| Formát | Šablona |
| --- | --- |
| Na výšku 1080 × 1350 (výchozí) | `2063:5779` |
| Čtverec 1200 × 1200 | `2063:5785` |

Vrstvy k úpravě: `Citát`, `Fotka (vyměňte za vlastní)`.

### Další formáty

LinkedIn banner `2060:5773` (tmavý, fotka týmu) a `2060:5778` (světlý), profilová fotka `2060:5783` / `2060:5787`, Clutch logo profilu `2063:5791` / `2063:5795`.

## Postup

1. **Zjisti zadání:** text příspěvku nebo hlavní myšlenku, šablonu (Myšlenka / Fotka s citátem), formát (výchozí na výšku 1080 × 1350), tmavou nebo světlou verzi (výchozí tmavá). U fotky s citátem si vyžádej fotku.
2. **Navrhni citát:** z textu příspěvku vyber nebo zkrať jednu větu, max. 3 řádky (orientačně do 60 znaků). Nabídni 2 až 3 varianty, pokud citát nebyl zadán.
3. **Uprav text podle pravidel** níže, hlavně uvozovky.
4. **Načti skill `figma-use`** a pracuj přes `use_figma`.
5. **Naklonuj šablonu** (`node.clone()`) do sekce `Příspěvky / <RRRR-MM>` na stránce Brand manuál (založ ji, pokud chybí). Pojmenuj `<RRRR-MM-DD> · <téma> · <Myšlenka|Fotka s citátem> · <Tmavá|Světlá>`.
6. **Vyměň obsah.** Před změnou textu načti fonty přes `getStyledTextSegments(['fontName'])`. Fotky nahrávej přes `upload_assets` s `nodeIds`. Autor je vždy **Mikoláš Voborský**, pokud uživatel neřekne jinak.
7. **Zkontroluj screenshotem:** text se nepřekrývá a nepřetéká, citát má max. 3 řádky (jinak zkrať text, písmo nezmenšuj), logo a autor jsou na místě.
8. **Předej:** název rámce. Export PNG ve 2× jen na požádání.

## Pravidla značky

- **Barvy:** navy 900 `#090E21`, bílá a šedé z palety. Tmavá verze je primární a tvoří většinu příspěvků, světlý přechod je doplňkový.
- **Žádná červená** v příspěvcích. Červená tečka patří jen obálkám blogu.
- **Písma:** Booton SemiBold pro citáty a nadpisy, Geist pro autora a odkaz. **Žádná kurzíva**, žádné barevné zvýraznění slov. Zvýrazňuje se jen velikostí a řezem.
- **Logo:** jen instance komponenty Logo, negativní na tmavém, pozitivní na světlém.
- **Jedna myšlenka na vizuál.** Vysvětlení patří do textu příspěvku.

## Pravidla textu

- **České uvozovky vždy:** „takto“, tedy dolní `„` (U+201E) na začátku a horní `“` (U+201C) na konci. Nikdy "rovné", “anglické” ani ”obrácené”. Vnořené ‚takto‘. Je-li citát celá věta, tečka je před koncovou uvozovkou: „Nevybrali nás.“
- Vykání, „Apadore“ (verzálky jen v logu), žádná dlouhá pomlčka (—), čísla s mezerou po tisících (1 641).
- Jednopísmenné předložky a spojky (k, s, v, z, o, u, a, i) nenechávej na konci řádku, použij pevnou mezeru (U+00A0).
- Tón: klidně, věcně, přínos pro klienta, důkazy místo superlativů.

## Kontrola před předáním

- [ ] Správná šablona, výchozí tmavá verze na výšku
- [ ] České uvozovky „…“, žádná kurzíva, žádná dlouhá pomlčka
- [ ] Žádná červená
- [ ] Autor Mikoláš Voborský (pokud nebylo řečeno jinak)
- [ ] Logo je instance komponenty Logo
- [ ] Citát max. 3 řádky, nic nepřetéká (screenshot)
- [ ] Nic mimo stránku Brand manuál nebylo změněno
